import { useState } from 'react'

export default function BMI() {
  const [height, setHeight] = useState(175)
  const [weight, setWeight] = useState(78)
  const bmi = weight / Math.pow(height/100, 2)
  const cat = bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal' : bmi < 30 ? 'Overweight' : 'Obese'

  return (
    <div className="max-w-md mx-auto border rounded-2xl p-4">
      <h2 className="font-semibold mb-3">BMI Calculator</h2>
      <div className="space-y-3">
        <label className="block">Height (cm)
          <input type="number" className="w-full border rounded p-2" value={height} onChange={e=>setHeight(+e.target.value)} />
        </label>
        <label className="block">Weight (kg)
          <input type="number" className="w-full border rounded p-2" value={weight} onChange={e=>setWeight(+e.target.value)} />
        </label>
      </div>
      <div className="mt-4 p-3 rounded bg-gray-100 dark:bg-gray-800">
        <div className="text-xl font-semibold">BMI: {bmi.toFixed(1)}</div>
        <div className="opacity-80">{cat}</div>
      </div>
      <p className="text-sm opacity-70 mt-2">Tip: log weekly weight in Calories page for trend graphs.</p>
    </div>
  )
}
